<?php

namespace App\Kassdoug\Tableadv;

class TableadvController{

    private $totalRegs;
    private $totalRegInPage;
    private $data;

    private $limit;
    private $offset;
    private $orderBy;
    private $direction;
    private $whereCol;
    private $whereValue;
    private $whereIndividual;

    private $table_primary;

    private $query;

    /**
     * metodo para iniciar a requisição de modo estático
     *
     * @param [type] $model
     * @param [type] $query
     * @param [type] $request
     * @return void
     */
    public static function run($model, $query, $request){
        return (new TableadvController)->process($model, $query, $request);
    }


    /**
     * Processo de busca dos dados
     * Metodos devem ser sequenciais no processo
     *
     * @param [type] $model
     * @param [type] $query
     * @param [type] $request
     * @return void
     */
    private function process($model, $query, $request)
    {

        $this->prepare($model, $query, $request);

        $this->conditional();

        $this->conditionalIndividual();

        $this->totalRegs();

        $this->limitOffset();

        $this->orderby();

        return $this->response();

    }

    /**
     * Prepara os dados vindos da requisição
     *
     * @param [type] $model
     * @param [type] $query
     * @param [type] $request
     * @return void
     */
    private function prepare($model, $query, $request){
        $this->limit = $request->limit;
        $this->offset = $request->offset;
        $this->orderBy = $request->orderby;
        $this->direction = $request->orderdirection;
        $this->whereCol = $request->whereColumn;
        $this->whereValue = $request->whereValue;
        $this->whereIndividual = $request->whereIndividual;
        $this->table_primary = (new $model)->getTable();
        $this->query = $query;
    }

    /**
     * Gera o sql 'where'
     *
     * @return void
     */
    private function conditionalIndividual(){

        if($this->whereIndividual !== null) {
            // print_r($this->whereIndividual);exit();
            foreach ($this->whereIndividual as $arr) {

                $this->query->where(function () use ($arr) {
                    if($arr['model'] != null){
                        $this->query->WhereHas($arr['model'], function ($subquery) use ($arr) {
                            $subquery->where($arr['field'], 'like', "%{$arr["value"]}%");
                        });
                    }else{
                        $this->query->Where("{$this->table_primary}.{$arr["field"]}",'like',"%{$arr["value"]}%");
                    }
                });
            }
        }
    }


    /**
     * Gera o sql 'where'
     *
     * @return void
     */
    private function conditional(){

        if($this->whereCol !== null && $this->whereValue !== null) {

            $this->query->Where(function () {

                foreach ($this->whereCol as $arr) {

                    if(is_array($arr)) {


                        $model = $arr['model'];
                        $col = $arr['field'];

                        $this->query->orWhereHas($model, function ($subquery) use ($col) {
                            $subquery->where($col, 'like', "%$this->whereValue%");
                        });
                    }else{
                        $col = $arr;
                        $this->query->orWhere("{$this->table_primary}.{$col}",'like',"%$this->whereValue%");
                    }
                }

            });

        }
    }

    /**
     * Pega o total de registros passados pelo 'where'
     *
     * @return void
     */
    private function totalRegs(){
        $this->totalRegs = $this->query->count();
    }

    /**
     * Limita a quantidade de registros a exibir
     *
     * @return void
     */
    private function limitOffset(){
        $this->query->limit($this->limit)->offset($this->offset);
    }

    /**
     * Ordena os dados
     *
     * @return void
     */
    private function orderby(){

        $field_order = $this->orderBy['db'];
        $index_field_sec = (mb_strpos($field_order ,".")!==false)
            ? count(explode(".",$field_order))-1
            : 0;

        $field_secondary = (mb_strpos($field_order ,".")!==false)
            ? explode(".",$field_order)[$index_field_sec ]
            : $this->orderBy['db'];

        if( array_key_exists('table_secondary',$this->orderBy) ){

            $table_primary = $this->table_primary;

            $tables = (mb_strpos($this->orderBy['table_secondary'],"|")!==false)
                ? explode("|",$this->orderBy['table_secondary'])
                : [$this->orderBy['table_secondary']];

            $fields_inner = (mb_strpos($this->orderBy['table_secondary'],"|")!==false)
                ? explode("|",$this->orderBy['field_inner_primary'])
                : [$this->orderBy['field_inner_primary']];

            $tabindx = count($tables)-1;
            $field_order = "{$tables[$tabindx]}.{$field_secondary}";

            foreach($tables as $index=>$obj){
                if($index == 0){
                    $table_sec = $table_primary;
                }
                else{
                    $previous_index = $index - 1;
                    $table_sec = $tables[ $previous_index];
                }
                $this->query->join($tables[$index], "{$table_sec}.{$fields_inner[$index]}", '=', "{$tables[$index]}.id");
            }

            $this->query->select("{$table_primary}.*");

        }


        $this->query->orderBy($field_order, $this->direction);
    }

    /**
     * Resposta padrão que o frontend precisa
     *
     * @return void
     */
    private function response(){

        $this->data = $this->query->get();
        $this->totalRegInPage = count($this->data);

        return response()->json([
            "total" => $this->totalRegs,
            "total_in_page" => $this->totalRegInPage,
            "data" => $this->data
        ]);
    }


}
