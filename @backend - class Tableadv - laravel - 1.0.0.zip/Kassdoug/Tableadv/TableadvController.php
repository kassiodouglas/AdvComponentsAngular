<?php

namespace App\Kassdoug\Tableadv;

class TableadvController{

    private $totalRegs;
    private $totalRegInPage;
    private $data;

    private $limit;
    private $offset;
    private $orderBy;
    private $direction;
    private $whereCol;
    private $whereValue;

    private $table_primary;

    private $query;

    /**
     * metodo para iniciar a requisição de modo estático
     *
     * @param [type] $model
     * @param [type] $query
     * @param [type] $request
     * @return void
     */
    public static function run($model, $query, $request){
        return (new TableadvController)->process($model, $query, $request);
    }


    /**
     * Processo de busca dos dados
     * Metodos devem ser sequenciais no processo
     *
     * @param [type] $model
     * @param [type] $query
     * @param [type] $request
     * @return void
     */
    private function process($model, $query, $request)
    {

        $this->prepare($model, $query, $request);

        $this->conditional();

        $this->totalRegs();

        $this->limitOffset();

        $this->orderby();

        return $this->response();

    }

    /**
     * Prepara os dados vindos da requisição
     *
     * @param [type] $model
     * @param [type] $query
     * @param [type] $request
     * @return void
     */
    private function prepare($model, $query, $request){
        $this->limit = $request->limit;
        $this->offset = $request->offset;
        $this->orderBy = $request->orderby;
        $this->direction = $request->orderdirection;
        $this->whereCol = $request->whereColumn;
        $this->whereValue = $request->whereValue;
        $this->table_primary = (new $model)->getTable();
        $this->query = $query;
    }

    /**
     * Gera o sql 'where'
     *
     * @return void
     */
    private function conditional(){

        if($this->whereCol !== null && $this->whereValue !== null) {

            $this->query->where(function () {

                foreach ($this->whereCol as $arr) {

                    if(is_array($arr)) {

                        $model = $arr['model'];
                        $col = $arr['field'];

                        $this->query->orWhereHas($model, function ($subquery) use ($col) {
                            $subquery->where($col, 'like', "%$this->whereValue%");
                        });
                    }else{
                        $col = $arr;
                        $this->query->orWhere("{$this->table_primary}.{$col}",'like',"%$this->whereValue%");
                    }
                }

            });

        }
    }

    /**
     * Pega o total de registros passados pelo 'where'
     *
     * @return void
     */
    private function totalRegs(){
        $this->totalRegs = $this->query->count();
    }

    /**
     * Limita a quantidade de registros a exibir
     *
     * @return void
     */
    private function limitOffset(){
        $this->query->limit($this->limit)->offset($this->offset);
    }

    /**
     * Ordena os dados
     *
     * @return void
     */
    private function orderby(){
        if( array_key_exists('table_secondary',$this->orderBy) ){

            $table_primary = $this->table_primary; //$orderBy['table_primary'];
            $field_inner_primary = $this->orderBy['field_inner_primary'];

            $table_secondary = $this->orderBy['table_secondary'];
            $field_secondary = $this->orderBy['field_secondary'];

            $field_order = "{$table_secondary}.{$field_secondary}";

            $this->query->join($table_secondary, "{$table_primary}.{$field_inner_primary}", '=', "{$table_secondary}.id")
                ->select("{$table_primary}.*")
                ->orderBy(  $field_order, $this->direction);
        }else{
            $this->query->orderBy($this->orderBy['db'], $this->direction);
        }
    }

    /**
     * Resposta padrão que o frontend precisa
     *
     * @return void
     */
    private function response(){

        $this->data = $this->query->get();
        $this->totalRegInPage = count($this->data);

        return response()->json([
            "total" => $this->totalRegs,
            "total_in_page" => $this->totalRegInPage,
            "data" => $this->data
        ]);
    }


}
